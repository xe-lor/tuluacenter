import React, { useEffect, useState } from "react";
import API from "../api.js";
import styles from "./stats.module.css";

export default function StatsPage() {
  const [data, setData] = useState(null);

  useEffect(() => {
    API.get("/teacher/stats").then((res) => {
      setData(res.data);
    });
  }, []);

  const renderHeader = () => (
    <div className={styles.cardHeader}>
      {/* Header background image */}
      <img
        src="/images/neonImage.png"
        alt=""
        className={styles.headerBackground}
      />

      {/* Dark overlay over the image */}
      <div className={styles.headerOverlay}></div>

      <div className={styles.headerContent}>
        <span className={styles.headerLabel}>ESPACE ENSEIGNANT</span>

        <h1 className={styles.headerTitle}>Statistiques</h1>

        <p className={styles.headerSubtitle}>
          Rapport financier de l'année scolaire.
        </p>
      </div>
    </div>
  );

  if (!data) {
    return (
      <div className={styles.pageContainer}>
        <div className={styles.managementCard}>
          {renderHeader()}

          <div className={styles.cardBody}>
            <div className={styles.emptyState}>
              <span className={styles.emptyAccent}></span>
              <span className={styles.emptyTitle}>
                Chargement des données
              </span>
              <span className={styles.emptySubtitle}>
                Veuillez patienter...
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.pageContainer}>
      <div className={styles.managementCard}>
        {renderHeader()}

        <div className={styles.cardBody}>
          {/* Monthly section */}
          <section className={styles.section}>
            <div className={styles.sectionHeading}>
              <div className={styles.sectionLeft}>
                <span className={styles.sectionNumber}>01</span>

                <div>
                  <span className={styles.sectionLabel}>APERÇU</span>
                  <h2 className={styles.sectionTitle}>
                    Statistiques mensuelles
                  </h2>
                </div>
              </div>

              <span className={styles.sectionDescription}>
                ÉVOLUTION DES REVENUS ET DES EFFECTIFS
              </span>
            </div>

            <div className={styles.tableContainer}>
              <table className={styles.table}>
                <thead>
                  <tr>
                    <th>Mois</th>
                    <th>Élèves</th>
                    <th>Total</th>
                    <th>Nette</th>
                  </tr>
                </thead>

                <tbody>
                  {Object.entries(data.orderedMonths).map(([num, name]) => {
                    const m = data.monthlyStats[name] || {};

                    return (
                      <tr key={num} className={styles.dataRow}>
                        <td>
                          <span className={styles.nameText}>{name}</span>
                        </td>
                        <td>{m.student_count || 0}</td>
                        <td>{m.total_price || 0} DH</td>
                        <td>
                          <span className={styles.netValue}>
                            {m.nette || 0} DH
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>

          {/* Class section */}
          <section className={styles.section}>
            <div className={styles.sectionHeading}>
              <div className={styles.sectionLeft}>
                <span className={styles.sectionNumber}>02</span>

                <div>
                  <span className={styles.sectionLabel}>RÉPARTITION</span>
                  <h2 className={styles.sectionTitle}>Résumé par classe</h2>
                </div>
              </div>

              <span className={styles.sectionDescription}>
                DÉTAIL PAR MATIÈRE ET NIVEAU
              </span>
            </div>

            <div className={styles.tableContainer}>
              <table className={styles.table}>
                <thead>
                  <tr>
                    <th>Matière</th>
                    <th>Niveau</th>
                    <th>Élèves</th>
                    <th>Total</th>
                    <th>Nette</th>
                  </tr>
                </thead>

                <tbody>
                  {data.classStats.length > 0 ? (
                    data.classStats.map((c, i) => (
                      <tr key={i} className={styles.dataRow}>
                        <td>
                          <span className={styles.nameText}>
                            {c.matiere_name}
                          </span>
                        </td>
                        <td>{c.niveau_name}</td>
                        <td>{c.student_count}</td>
                        <td>{c.total_price} DH</td>
                        <td>
                          <span className={styles.netValue}>
                            {c.nette} DH
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr className={styles.emptyRow}>
                      <td colSpan="5">
                        <div className={styles.emptyState}>
                          <span className={styles.emptyAccent}></span>
                          <span className={styles.emptyTitle}>
                            Aucune donnée
                          </span>
                          <span className={styles.emptySubtitle}>
                            Aucune classe à afficher pour le moment.
                          </span>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>

                <tfoot>
                  <tr className={styles.footRow}>
                    <td colSpan="4">
                      <span className={styles.totalLabel}>TOTAL NETTE</span>
                    </td>

                    <td>
                      <span className={styles.grandTotal}>
                        {data.totalNet} DH
                      </span>
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}